__author__ = 'ChrisPOConnell'
'''
Assignment 4
__init__.py
'''
from start import *

start()