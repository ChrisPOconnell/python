__author__ = 'ChrisPOConnell'
'''
Assignment 4
from test.test_importlib.import_.test_packages import ParentModuleTests
from test.test_importlib.import_.test_packages import ParentModuleTests
gui.py
'''

from tkinter import *
from start import start

#from PIL import Image, ImageTK

# Feature 21.1 Assignment 4
class GuiMainMenu(Frame):
    def __init__(self,Parent):
        Frame.__init__(self,Parent)
        self.parent = Parent
        self.GuiInit()
    
    def GuiInit(self):
        # Adds title to top of window.
        self.parent.title("Catalog Staging Program")
        
        # Feature 21.4 Assignment 4
        self.button1 = Button(self.parent, text = "start program!", command = start)
        self.button1.pack()
        
        # Creates main menu bar object.
        menu_bar=Menu(self.parent)
        # the next line shuts off the dashed line that appeared at the top of
        # a menu.
        menu_bar.option_add('*tearOff', FALSE)
        
        # Creates submenus
        file_options = Menu(self.parent)
        help_options = Menu(self.parent)
        
        # Adds menu_bar to parent object.  
        self.parent.config(menu=menu_bar)
        
        '''
        Functions used in the buttons are created in this section!
        '''
        
        # Feature 21.3 Assignment 4
        def display_help_readme():
            master=Tk()
            fileR = open('README.txt')
            readmefile = fileR.read()
            help_readme = Message(master, text = readmefile)
            help_readme.pack()
        
        # Feature 21.2 Assignment 4 
        def display_help_about():
            master = Tk()
            help_about = Label(master, text = "Help -> About:  Catalog Staging Program - Assignment 4")
            help_about.pack()        
            
        def onExit(): self.quit()
                          
        # Populate menu_bar with submenus.
        menu_bar.add_cascade(label="File",menu=file_options)
        menu_bar.add_cascade(label="Help",menu=help_options)
        
        # Create onExit function and add to File menu
        #file_options.add_command(label = "Your name", command = display_file_entry)
        #file_options.add_command(label = "Make entry", command = )
        
        # Populates File Menu
        file_options.add_command(label = "Exit",command = onExit)
        
        # Populates Help Menu
        help_options.add_command(label = "README",command=display_help_readme)
        help_options.add_command(label = "About", command = display_help_about)

def main_function():
    root = Tk()
    root.geometry("450x250+600+400")  # sets size for window + positions it on screen
    # width, height of window, x screen coordinate, y coordinate
    #im = Image.open('data_files/logo.jpg')
    #tkimage = ImageTk.PhotoImage(im)
    #myvar=root.Label(root,image = tkimage)
    #myvar.place(x=0, y=0, relwidth=1, relheight=1)
    app = GuiMainMenu(root)
    root.mainloop()

if __name__ == '__main__':
    # http://stackoverflow.com/questions/419163/what-does-if-name-main-do
    main_function()